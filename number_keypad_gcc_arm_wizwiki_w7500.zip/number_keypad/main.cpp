#include "mbed.h"
#include "DebounceIn.h"
 
Serial pc(USBTX, USBRX);

DigitalOut p0(D0, 1);
DigitalOut p1(D1, 1);
DigitalOut p2(D2, 1);
DigitalOut p3(D3, 1);
DebounceIn p4(D4);
DebounceIn p5(D5);
DebounceIn p6(D6);
DebounceIn p7(D7);
char key_map[] = {
    'D', 'C', 'B', 'A',
    '#', '9', '6', '3',
    '0', '8', '5', '2',
    '*', '7', '4', '1'};

  
int main() {

    abc:

    int key_old = -1;
  
   int flag = 0;
  
    while(1) {
      
        int key_index = -1;
      
        for (int i=0; i<4; ++i) {
          
            if (i == 0) {
                p0 = 1;
                p1 = 0;
                p2 = 0;
                p3 = 0;
            } else if (i == 1) {
                p0 = 0;
                p1 = 1;
                p2 = 0;
                p3 = 0;
            } else if (i == 2) {
                p0 = 0;
                p1 = 0;
                p2 = 1;
                p3 = 0;
            } else if (i == 3) {
                p0 = 0;
                p1 = 0;
                p2 = 0;
                p3 = 1;
            }
            wait_ms(50);
          
            if (p4 == 1) {
                key_index = i * 4;
                break;
            } else if (p5 == 1) {
                key_index = i * 4 + 1;
                break;
            } else if (p6 == 1) {
                key_index = i * 4 + 2;
                break;
            } else if (p7 == 1) {
                key_index = i * 4 + 3;
                break;
            }          
        }          
      
        if (key_index != -1 && key_index != key_old) {
            pc.printf("Key: %d, %c\n", key_index, key_map[key_index]);
            if(key_map[key_index] == '7')
            {
                pc.printf("Key Found %c \n",key_map[key_index]);
                pc.printf("Flag Found");
                //flag = 3;
           
            }
             
            if(flag == 3)
            {
               
                pc.printf("Input Locked");
                while(1)
                {
                    switch(key_map[key_index])
                    {
                          case '*':
                          {
                              pc.printf("Input *");
                              goto abc;                   
                            }
                            break;
                            default:
                            {
                                //pc.printf("default");
                            }
                            
                    }
                }
            }
            else
            {
             pc.printf("Key  not Found key pressed is %c \n",key_map[key_index]);  
             flag = flag + 1;
            }
               
           
            //wait(1);
        }
      
        key_old = key_index;
    }  

}